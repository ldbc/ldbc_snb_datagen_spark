Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/668f1bda1ad3598aa229e135fa1e9e44323042d1>
