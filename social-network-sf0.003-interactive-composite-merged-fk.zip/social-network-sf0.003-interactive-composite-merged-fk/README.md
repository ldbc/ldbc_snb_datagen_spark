Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/3bb5662078fc7314ad20aceefc040a9b4705ee24>
