Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/5692ceaddb264c11b32f9e9957b27d977bda31d3>
