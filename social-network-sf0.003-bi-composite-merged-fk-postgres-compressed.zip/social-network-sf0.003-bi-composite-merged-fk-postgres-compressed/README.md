Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/49f35d1cba3552ff3e2a270bca511abb3cc73b94>
