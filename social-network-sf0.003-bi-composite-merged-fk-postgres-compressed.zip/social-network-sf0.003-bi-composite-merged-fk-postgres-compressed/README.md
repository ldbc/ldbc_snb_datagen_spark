Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/6b8aa64b40719678b97c750946a25f920e44f397>
