Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/149d2120deb9c849b32f91479ac706b9197e61b2>
