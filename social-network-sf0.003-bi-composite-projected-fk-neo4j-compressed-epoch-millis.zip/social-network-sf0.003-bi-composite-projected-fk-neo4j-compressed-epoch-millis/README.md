Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/ac4d614e8912686ecfd6bb7807fbf51f90cf1630>
