Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/44cf9c2748a41a7b76cdde0002b700a68175f128>
