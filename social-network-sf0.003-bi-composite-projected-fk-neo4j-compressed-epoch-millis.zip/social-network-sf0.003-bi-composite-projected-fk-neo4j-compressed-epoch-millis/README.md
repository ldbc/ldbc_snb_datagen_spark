Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/a2210c52ddeceeeafbbdd4d4d166d0d0da82f739>
