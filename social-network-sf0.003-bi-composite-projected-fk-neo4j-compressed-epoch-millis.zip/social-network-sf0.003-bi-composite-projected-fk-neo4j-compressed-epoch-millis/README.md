Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/2d2f0dd2cc22690a9ac8d36375161dad50008528>
