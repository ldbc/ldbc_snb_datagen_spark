Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/4439c687d74242e662093ce14b386f323ce1cc2f>
