Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/1551688bcffa64ecdfbcad130e9a90936dba6c6d>
