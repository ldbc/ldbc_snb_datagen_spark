Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/8461db7a2a12db8686d26ff53fa4d05721842666>
