Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/621ef472cf77e065a9fb63e1d29aae45116b0dc6>
