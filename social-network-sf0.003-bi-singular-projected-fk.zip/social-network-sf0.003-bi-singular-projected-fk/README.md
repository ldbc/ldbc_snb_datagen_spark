Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/754526ae22bcdbb827e2e1c524eedc8a44351850>
