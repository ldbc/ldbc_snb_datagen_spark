Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/9bc1fb36fa7edf424fbc06218f764599b9cbd8c5>
