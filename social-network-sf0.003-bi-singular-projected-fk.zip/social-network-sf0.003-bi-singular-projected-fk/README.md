Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/bf02fdefb1aa30e925ee3e42806ddc22b0051037>
