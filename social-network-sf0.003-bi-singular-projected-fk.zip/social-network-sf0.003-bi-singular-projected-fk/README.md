Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/a77f54c3c1e97461dedc15eb1411e05e1ee7d18a>
