Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/24477da973eeb645dce6ccd92d118a5f4c092fd5>
