Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/fbec425ecfbb89c3a563c60ad0066f0256631240>
