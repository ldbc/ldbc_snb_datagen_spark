Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/f52f6b5cbb5d86d3e2214ec5d7cf5884aaf24691>
