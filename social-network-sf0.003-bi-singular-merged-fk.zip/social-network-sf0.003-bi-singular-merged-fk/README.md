Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/829b7a04cfeac0cf7fe4bb6aef0846ffc2fb1ee5>
