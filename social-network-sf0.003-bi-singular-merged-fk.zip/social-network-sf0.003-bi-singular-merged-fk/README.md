Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/49b21a8474126dd7e98f93094f9c2808c1f3ea4d>
