Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/abeae646c8911f6188bec8829d32af779957a1b9>
