Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/1ba29363f7942a65b2a14213e0d4d5e637e59f54>
