Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/1271703f7c5506ab83e1cabda631d348fdc9e277>
