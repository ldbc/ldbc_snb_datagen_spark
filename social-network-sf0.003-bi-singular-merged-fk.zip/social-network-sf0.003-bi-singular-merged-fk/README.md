Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/250da2805fbd9ec25833d954ecaa224286563a83>
