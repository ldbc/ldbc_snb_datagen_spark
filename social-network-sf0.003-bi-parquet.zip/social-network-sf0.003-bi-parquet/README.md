Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/3a315c2ba90a27fa93a806b0462e42167ae8ff90>
