Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/a773275eca5597fd7d92b45a732e55f7f44368da>
