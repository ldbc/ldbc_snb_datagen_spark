Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/58557f6e943e92eb94287213edbc67a1913b4db5>
