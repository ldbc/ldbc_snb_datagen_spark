Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/6d5951438ed833f15f7767ac6818ee4afccd8567>
