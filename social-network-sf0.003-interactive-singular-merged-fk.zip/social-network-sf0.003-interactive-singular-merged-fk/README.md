Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/723105ac9a1b19192f5961e219e752cff58fd354>
