Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/f38ca7e571c2d70721720eaf611e08af84c084bd>
