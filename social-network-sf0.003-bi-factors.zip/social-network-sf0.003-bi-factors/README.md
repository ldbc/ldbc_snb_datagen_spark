Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/efbb88eba761b8bfe089ebbb8d3bb01b115dd1ad>
