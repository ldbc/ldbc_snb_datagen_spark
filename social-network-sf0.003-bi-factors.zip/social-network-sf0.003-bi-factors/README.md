Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/7895e28cd95f10402a8cea52c9d26961943435a3>
