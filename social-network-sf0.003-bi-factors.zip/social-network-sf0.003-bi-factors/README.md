Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/848c3948e137e07223c657fcb549594fff82f5c6>
