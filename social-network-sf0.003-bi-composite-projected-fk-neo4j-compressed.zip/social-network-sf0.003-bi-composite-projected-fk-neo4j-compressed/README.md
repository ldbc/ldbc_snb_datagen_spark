Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/0596fd2cad374abe03185f68ed37a66bcc1e4290>
