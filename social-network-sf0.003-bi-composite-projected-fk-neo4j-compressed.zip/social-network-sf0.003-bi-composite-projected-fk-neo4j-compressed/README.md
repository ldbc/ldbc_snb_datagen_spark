Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/bb9bdf7b4d0c634e37c07c49039d67eae82c3f16>
