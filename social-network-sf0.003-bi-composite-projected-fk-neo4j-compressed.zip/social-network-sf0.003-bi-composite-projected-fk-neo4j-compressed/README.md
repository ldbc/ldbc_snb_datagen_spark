Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/b3dc986898efac7c1676abba865a30865334922e>
