Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/6aae25f4acf37b6dbd72a709dc5bbc7e7a0fe674>
