Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/b16c8f7cf40a674a317ddd0624ca2af861aa2966>
