Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/d6a27d77d6d32cce423b6e76c34f95532bd38441>
