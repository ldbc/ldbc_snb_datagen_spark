Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/01c0abe8984c4449e61556b5f807fb25dfb6f483>
