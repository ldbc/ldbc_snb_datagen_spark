Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/903f544a654cbf75765c91b3de3b9bd78180efcc>
