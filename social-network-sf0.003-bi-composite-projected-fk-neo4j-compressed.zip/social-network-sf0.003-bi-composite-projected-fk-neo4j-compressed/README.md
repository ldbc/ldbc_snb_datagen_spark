Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/ad99962450af572f705988038dd8000a065e2887>
