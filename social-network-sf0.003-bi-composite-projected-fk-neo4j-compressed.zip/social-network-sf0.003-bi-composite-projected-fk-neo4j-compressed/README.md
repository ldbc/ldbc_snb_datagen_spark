Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/8ec422c4516b12d70541c555a4bc95e121cdc685>
