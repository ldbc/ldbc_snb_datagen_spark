Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/6fb01114bd7e666ae0ff27810089dd46cee01612>
