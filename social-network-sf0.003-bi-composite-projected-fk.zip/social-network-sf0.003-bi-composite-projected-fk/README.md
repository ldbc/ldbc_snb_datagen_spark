Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/95be89f0fc8903ddcf14ebff8636f43d5de4d146>
