Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/080535ee51e28346df0e73aea0f37a1235d83d19>
