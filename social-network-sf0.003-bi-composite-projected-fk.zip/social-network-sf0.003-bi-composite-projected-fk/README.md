Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/11397c2093db47aae0737c18ab7b8b100c15e681>
