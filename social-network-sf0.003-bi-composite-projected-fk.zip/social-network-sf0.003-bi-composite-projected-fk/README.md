Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/5f729be3f47b7bdea3b097f28cb5b9b2f1327a88>
