Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/2b22c4375f610999b0f8286ae61d433dd2d3048a>
