Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/eb450a9ebea2a5949a1dd7a50960457316b51531>
