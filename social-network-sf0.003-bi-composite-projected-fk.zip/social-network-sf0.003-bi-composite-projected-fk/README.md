Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/2ec1acf07c3c034c6084e41f29f568e7668dfce2>
