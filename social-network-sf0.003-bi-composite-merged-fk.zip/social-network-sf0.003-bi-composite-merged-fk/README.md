Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/2337b2791d29b50f1b3b29311eaa2e874b618f0c>
