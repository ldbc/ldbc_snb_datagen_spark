Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/10f1bf9b56e960513e6a949b2eca2bfd53a0c0c6>
