Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/2b19ddc250bf169230fcf237bf1def11e7212792>
