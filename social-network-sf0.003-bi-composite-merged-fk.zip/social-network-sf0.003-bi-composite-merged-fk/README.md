Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/148f14dfd398d512dd41605c73a6859f894a4340>
