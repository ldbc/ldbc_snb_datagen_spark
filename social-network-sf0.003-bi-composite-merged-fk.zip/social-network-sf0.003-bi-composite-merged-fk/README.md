Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/2bc2194450ccb0b965f02bf1f34a1a8843d1e292>
