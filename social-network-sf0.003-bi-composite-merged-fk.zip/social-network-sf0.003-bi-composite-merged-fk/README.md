Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/6fab847d8bbe3a63409b5684cae74694aa3aa898>
