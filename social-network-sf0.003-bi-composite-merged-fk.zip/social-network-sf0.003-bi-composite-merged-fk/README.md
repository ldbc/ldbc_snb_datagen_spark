Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/d060baa8f4bf013ee3fb55a50b2030d94bbcc168>
