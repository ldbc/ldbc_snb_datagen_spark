Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/b1608fcc7b8f37ee91b7c8d451b206528bd92971>
