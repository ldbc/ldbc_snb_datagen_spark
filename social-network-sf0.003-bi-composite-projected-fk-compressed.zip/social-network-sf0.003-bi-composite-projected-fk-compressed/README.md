Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/f4c92c7349b8989cad9d050e8d0034c3011624a2>
