Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/d6bfc51fcb787876492290e2c5c80e5480523025>
