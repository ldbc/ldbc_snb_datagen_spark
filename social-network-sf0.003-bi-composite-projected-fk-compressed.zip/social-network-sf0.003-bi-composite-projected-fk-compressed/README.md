Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/1d60a657a2816a4052fa1737663348b099bceb32>
