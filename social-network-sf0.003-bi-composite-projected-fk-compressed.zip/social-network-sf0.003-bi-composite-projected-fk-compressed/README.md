Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/7da837814d2f3741de25a278f846ea9126b38f87>
