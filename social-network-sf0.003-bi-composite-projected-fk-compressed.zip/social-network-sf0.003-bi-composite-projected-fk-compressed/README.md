Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/2459f4e45834c78902a50511fc64a05c48dd4029>
