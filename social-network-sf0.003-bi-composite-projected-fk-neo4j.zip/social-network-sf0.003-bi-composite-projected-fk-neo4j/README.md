Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/a0291c4acb41d2915d279d52f9cc5f0a1a19e4d9>
