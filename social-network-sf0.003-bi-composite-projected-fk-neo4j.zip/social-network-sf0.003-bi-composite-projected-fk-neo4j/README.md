Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/600bcdf32f88e82096749a688ebe78fa5fbfcd67>
