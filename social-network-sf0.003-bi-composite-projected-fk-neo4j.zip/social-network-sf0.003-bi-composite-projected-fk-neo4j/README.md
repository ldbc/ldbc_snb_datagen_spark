Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/07a3d1880b39262425b3152c8b280ba3acca3f91>
