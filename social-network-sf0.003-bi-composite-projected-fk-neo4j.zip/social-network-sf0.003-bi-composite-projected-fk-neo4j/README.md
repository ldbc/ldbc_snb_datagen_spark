Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/08cf56a8cc731625d4c5fec8a2b90fa7c7e42109>
