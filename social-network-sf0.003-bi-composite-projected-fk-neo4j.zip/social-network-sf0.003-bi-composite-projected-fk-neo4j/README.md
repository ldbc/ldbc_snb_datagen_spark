Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/572154654ea14df728ae35af56c0745add2415b7>
